function h = htheta(theta, x)

h = sum(theta'.*x, 'all');

end
